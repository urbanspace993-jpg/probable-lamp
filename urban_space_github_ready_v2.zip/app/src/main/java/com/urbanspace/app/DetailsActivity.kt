package com.urbanspace.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.urbanspace.app.databinding.ActivityDetailsBinding

class DetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.name.text = intent.getStringExtra("product_name")
        binding.price.text = intent.getStringExtra("product_price")
        binding.desc.text = intent.getStringExtra("product_desc")
    }
}
