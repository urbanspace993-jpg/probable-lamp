package com.urbanspace.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.urbanspace.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportFragmentManager.beginTransaction()
            .replace(binding.container.id, HomeFragment())
            .commit()
        binding.bottomNav.setOnItemSelectedListener { item ->
            when(item.itemId) {
                R.id.menu_home -> supportFragmentManager.beginTransaction().replace(binding.container.id, HomeFragment()).commit()
                R.id.menu_products -> supportFragmentManager.beginTransaction().replace(binding.container.id, ProductsFragment()).commit()
                R.id.menu_offers -> supportFragmentManager.beginTransaction().replace(binding.container.id, OffersFragment()).commit()
                R.id.menu_contact -> supportFragmentManager.beginTransaction().replace(binding.container.id, ContactFragment()).commit()
            }
            true
        }
    }
}
