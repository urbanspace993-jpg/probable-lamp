package com.urbanspace.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.urbanspace.app.databinding.FragmentContactBinding

class ContactFragment : Fragment() {
    private var _binding: FragmentContactBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentContactBinding.inflate(inflater, container, false)
        binding.btnWhatsApp.setOnClickListener {
            val url = "https://wa.me/918000000000" // placeholder
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        binding.btnMaps.setOnClickListener {
            val g = "geo:12.9716,77.5946?q=Urban+Space+Bangalore" // placeholder
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(g)))
        }
        binding.btnPay.setOnClickListener {
            startActivity(Intent(requireContext(), QRActivity::class.java))
        }
        return binding.root
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
