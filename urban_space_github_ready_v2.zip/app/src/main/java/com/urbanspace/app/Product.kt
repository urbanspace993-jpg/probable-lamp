package com.urbanspace.app

data class Product(val name: String, val price: String, val description: String)
