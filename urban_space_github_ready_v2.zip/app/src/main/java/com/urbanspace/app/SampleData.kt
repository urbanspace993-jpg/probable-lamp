package com.urbanspace.app

object SampleData {
    val products = listOf(
        Product("2-seater Sofa", "₹12,999", "Comfortable fabric sofa - 2 seater"),
        Product("Queen Bed", "₹18,499", "Solid base queen bed"),
        Product("Recliner Chair", "₹9,999", "Single recliner with PU leather"),
        Product("3-door Wardrobe", "₹14,499", "Spacious wardrobe with shelves"),
        Product("Shoe Rack", "₹1,999", "4-tier shoe rack")
    )
}
