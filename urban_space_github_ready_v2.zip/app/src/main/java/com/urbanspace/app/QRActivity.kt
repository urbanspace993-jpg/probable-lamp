package com.urbanspace.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.urbanspace.app.databinding.ActivityQrBinding

class QRActivity : AppCompatActivity() {
    private lateinit var binding: ActivityQrBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQrBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
