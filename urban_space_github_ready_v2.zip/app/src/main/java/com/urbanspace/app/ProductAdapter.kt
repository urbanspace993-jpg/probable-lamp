package com.urbanspace.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.urbanspace.app.databinding.ItemProductBinding

class ProductAdapter(private val items: List<Product>, val onClick: (Product)->Unit) : RecyclerView.Adapter<ProductAdapter.VH>() {
    inner class VH(val binding: ItemProductBinding) : RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.binding.name.text = p.name
        holder.binding.price.text = p.price
        holder.binding.root.setOnClickListener { onClick(p) }
    }
    override fun getItemCount() = items.size
}
