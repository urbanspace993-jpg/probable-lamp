package com.urbanspace.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.urbanspace.app.databinding.FragmentProductsBinding

class ProductsFragment : Fragment() {
    private var _binding: FragmentProductsBinding? = null
    private val binding get() = _binding!!
    private val items = SampleData.products
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProductsBinding.inflate(inflater, container, false)
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = ProductAdapter(items) { p ->
            val i = Intent(requireContext(), DetailsActivity::class.java)
            i.putExtra("product_name", p.name)
            i.putExtra("product_price", p.price)
            i.putExtra("product_desc", p.description)
            startActivity(i)
        }
        return binding.root
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
