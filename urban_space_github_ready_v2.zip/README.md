# Urban Space - Elegant Android app (GitHub-ready)

This project is ready to upload to GitHub. It includes a GitHub Actions workflow that will build a debug APK automatically.

## How to get the APK (quick)
1. Create a new repository on GitHub and upload all files from this project (drag & drop in the web UI).
2. Wait for GitHub Actions to run (visible in Actions tab). The build usually finishes in 3-8 minutes.
3. Open the workflow run and download the `app-debug.apk` artifact from the run's Artifacts section.

## Notes
- The project includes placeholders for WhatsApp number, Maps location, QR image, and product photos. You can replace them later in `app/src/main/res/drawable` and `SampleData.kt`.
- If you prefer, I can update the placeholders with your content later and generate an updated ZIP.
